<h1>new notification</h1>
<span>{{Session::get('msg')}}</span>
<h2>Thank You</h2>